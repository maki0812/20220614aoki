      <aside class="sidebar">
        <div class="secondview">
          <a href="https://coachtech.site/"><img src="./img/banner.png" alt=""></a>
        </div>
        <div class="editorial_department">
          <div class="editorial_img">
            <img src="./img/estramedia__logo.png" ait="">
          </div>
          <h3 class="editorial_ttl">エストラ編集部</h3>
          <p class="editorial_text">プロフィール文が入ります。プロフィール文が入ります。プロフィール文が入ります。プロフィール文が入ります。プロフィール文が入ります。</p>
        </div>
        <div class="category">
          <h3 class="category_ttl">Category</h3>
          <ul class="category_list">
            <li class="category_item">
              <a href="" class="category_link">
                HTML
              </a>
            </li>
            <li class="category_item">
              <a href="" class="category_link">CSS</a>
            </li>
            <li class="category_item">
              <a href="" class="category_link">JavaScript</a>
            </li>
            <li class="category_item">
              <a href="" class="category_link">PHP</a>
            </li>
            <li class="category_item">
              <a href="" class="category_link">MySQL</a>
            </li>
          </ul>
        </div>
      </aside>