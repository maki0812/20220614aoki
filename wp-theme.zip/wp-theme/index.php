<main>

  <div class="firstview">
    <h1 class="firstview-ttl">Commit to the growth<br>for everyone</h1>
  </div>
  <div class="container">

    <article class="content">
      <div class="content_ttl">
        <p class="newpost__sub-ttl">New Post</p>
        <h3 class="newpost__ttl">新着情報</h3>
      </div>
      <div class="flex__item">
        <div class="blog__warp">
          <div class="news__img">
            <img src="img/blog__first.jpg" alt="">
          </div>
          <div class="blog__content">
            <div class="card__cat">キャリア</div>
            <h3 class="blog__ttl">プログラミングでフリーランスになるには？？</h3>
            <div class="tag">
              <p class="bolg__date">2021-02-26</p>
            </div>
          </div>
        </div>
        <div class="blog__warp">
          <div class="news__img">
            <img src="img/blog__first.jpg" alt="">
            <div class="card__cat">キャリア</div>
          </div>
          <div class="blog__content">
            <h3 class="blog__ttl">プログラミングでフリーランスになるには？？</h3>
            <div class="tag">
              <p class="bolg__date">2021-02-26</p>
            </div>
          </div>
        </div>
        <div class="blog__warp">
          <div class="news__img">
            <img src="img/blog__first.jpg" alt="">
            <div class="card__cat">キャリア</div>
          </div>
          <div class="blog__content">
            <h3 class="blog__ttl">プログラミングでフリーランスになるには？？</h3>
            <div class="tag">
              <p class="bolg__date">2021-02-26</p>
            </div>
          </div>
        </div>
        <div class="blog__warp">
          <div class="news__img">
            <img src="img/blog__first.jpg" alt="">
            <div class="card__cat">キャリア</div>
          </div>
          <div class="blog__content">
            <h3 class="blog__ttl">プログラミングでフリーランスになるには？？</h3>
            <div class="tag">
              <p class="bolg__date">2021-02-26</p>
            </div>
          </div>
        </div>
        <div class="blog__warp">
          <div class="news__img">
            <img src="img/blog__first.jpg" alt="">
            <div class="card__cat">キャリア</div>
          </div>
          <div class="blog__content">
            <h3 class="blog__ttl">プログラミングでフリーランスになるには？？</h3>
            <div class="tag">
              <p class="bolg__date">2021-02-26</p>
            </div>
          </div>
        </div>
        <div class="blog__warp">
          <div class="news__img">
            <img src="img/blog__first.jpg" alt="">
            <div class="card__cat">キャリア</div>
          </div>
          <div class="blog__content">
            <h3 class="blog__ttl">プログラミングでフリーランスになるには？？</h3>
            <div class="tag">
              <p class="bolg__date">2021-02-26</p>
            </div>
          </div>
        </div>
      </div>
    </article>
</main>