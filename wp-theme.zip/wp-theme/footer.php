<footer>
  <p>Copyright © 2022 coachtechサンプルテスト All Rights Reserved.</p>
</footer>
</body>

</html>