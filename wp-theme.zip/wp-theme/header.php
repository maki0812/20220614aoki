<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>estra magazine</title>
  <link rel="stylesheet" href="css/reset.css" />
  <link rel="stylesheet" href="css/style.css" />
  <link href="https://fonts.googleapis.com/css2?family=Indie+Flower&family=Noto+Serif+JP:wght@900&display=swap" rel="stylesheet">
</head>

<body>
  <header>
    <div class="header_logo">
      <a href="">
        <img src="./img/estramedia__logo.png">
      </a>
    </div>
    <nav class="header_nav">
      <ul class="nav_flex__item">
        <li class="nav__list">
          <a href="" class="nav__link">HTML</a>
        </li>
        <li class="nav__list">
          <a href="" class="nav__link">CSS</a>
        </li>
        <li class="nav__list">
          <a href="" class="nav__link">JavaScript</a>
        </li>
        <li class="nav__list">
          <a href="" class="nav__link">PHP</a>
        </li>
        <li class="nav__list">
          <a href="" class="nav__link">MySQL</a>
        </li>
      </ul>
    </nav>
  </header>